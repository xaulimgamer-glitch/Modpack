RefinedTorches_InternalState = RefinedTorches_InternalState or {}

global.fall = 0.0;
local l = (context.bl and 1) or -1
local item = context.item
local matrices = context.matrices
local mainHand = context.mainHand
local player = context.player
local deltaTime = context.deltaTime
local yr = P:getYaw(player) * math.pi / 180.0
local velTotal = math.sqrt(P:getXSpeed(player)^2 + P:getZSpeed(player)^2)
local velFrente = P:getXSpeed(player) * -M:sin(yr) + P:getZSpeed(player) * M:cos(yr)
local velLateral = P:getXSpeed(player) * M:cos(yr) + P:getZSpeed(player) * M:sin(yr)
local apenasLateral = math.abs(velLateral) > 0.05 and math.abs(velFrente) < 0.05
local andandoRe = velFrente < -0.05
local apenasCorrer = ${apenasCorrer} == true
local noChao = P:isOnGround(player)
local emMovimento = not andandoRe and ((apenasCorrer and (velTotal > 0.12) and (noChao or velTotal > 0.165)) or (not apenasCorrer and (velTotal > 0.05)))
local correndo = velTotal > 0.12 and velFrente > 0.1
local baixoDaAgua = P:isSubmergedInWater(player)
local tocandoAgua = P:isTouchingWater(player) and not baixoDaAgua and P:isOnGround(player)
local sneaking = P:isSneaking(player)
local walking = emMovimento and not tocandoAgua and (not apenasCorrer and (fall > -1.1 and fall < 3) or apenasCorrer and (correndo and (fall > -1.1 and fall < 3) or not correndo))
local tochas = {"minecraft:torch", "minecraft:soul_torch", "minecraft:copper_torch", "minecraft:redstone_torch"}
local velas = {"minecraft:candle", "minecraft:white_candle", "minecraft:light_gray_candle", "minecraft:gray_candle", "minecraft:black_candle", "minecraft:brown_candle", "minecraft:red_candle", "minecraft:orange_candle", "minecraft:yellow_candle", "minecraft:lime_candle", "minecraft:green_candle", "minecraft:cyan_candle", "minecraft:light_blue_candle", "minecraft:blue_candle", "minecraft:purple_candle", "minecraft:magenta_candle", "minecraft:pink_candle"}
local chaveSmoother  = mainHand and "smootherWalk_MAIN"   or "smootherWalk_OFF"
local chaveAgua      = mainHand and "smootherAgua_MAIN"   or "smootherAgua_OFF"
local chaveAguaState = mainHand and "aguaState_MAIN"      or "aguaState_OFF"
local chaveNaAgua    = mainHand and "smootherNaAgua_MAIN" or "smootherNaAgua_OFF"
local chaveSneaking  = mainHand and "smootherSneak_MAIN"  or "smootherSneak_OFF"

local SmootherWalk   = RefinedTorches_InternalState[chaveSmoother] or 0.0
local SmootherAgua   = RefinedTorches_InternalState[chaveAgua]     or 1.0
local prevAgua       = RefinedTorches_InternalState[chaveAguaState] or false
local SmootherNaAgua = RefinedTorches_InternalState[chaveNaAgua]   or 0.0
local SmootherSneak  = RefinedTorches_InternalState[chaveSneaking]  or 0.0

if walking and ((not apenasCorrer and not apenasLateral) or (apenasCorrer and correndo)) then
    SmootherWalk = SmootherWalk + 0.04 * deltaTime * 30
else
    SmootherWalk = SmootherWalk - 0.06 * deltaTime * 30
end
SmootherWalk = M:clamp(SmootherWalk, 0, 1)

if baixoDaAgua then
    SmootherAgua = SmootherAgua - 0.05 * deltaTime * 30
else
    SmootherAgua = SmootherAgua + (prevAgua and 0.07 or 0.05) * deltaTime * 30
end
SmootherAgua = M:clamp(SmootherAgua, 0, 1)

if tocandoAgua then
    SmootherNaAgua = SmootherNaAgua + 0.04 * deltaTime * 30
else
    SmootherNaAgua = SmootherNaAgua - 0.06 * deltaTime * 30
end
SmootherNaAgua = M:clamp(SmootherNaAgua, 0, 1)

if sneaking then
    SmootherSneak = SmootherSneak + 0.04 * deltaTime * 30
else
    SmootherSneak = SmootherSneak - 0.06 * deltaTime * 30
end
SmootherSneak = M:clamp(SmootherSneak, 0, 1)

RefinedTorches_InternalState[chaveSmoother]  = SmootherWalk
RefinedTorches_InternalState[chaveAgua]      = SmootherAgua
RefinedTorches_InternalState[chaveAguaState] = baixoDaAgua
RefinedTorches_InternalState[chaveNaAgua]    = SmootherNaAgua
RefinedTorches_InternalState[chaveSneaking]  = SmootherSneak

local smoothAndar  = Easings:easeInOutSine(SmootherWalk) * SmootherAgua
local smoothNaAgua = Easings:easeInOutSine(SmootherNaAgua) * SmootherAgua
local smoothSneak  = Easings:easeInOutSine(SmootherSneak)
local smooth = M:clamp(smoothAndar + smoothNaAgua, 0, 1)

for _, id in pairs(tochas) do
    if I:isOf(item, Items:get(id)) then
            --patovskiz was here
        M:moveX(matrices, smooth * (1 - smoothSneak) * -0.1 * l)
        M:moveZ(matrices, smooth * (1 - smoothSneak) * -0.05)
        M:rotateZ(matrices, smooth * (1 - smoothSneak) * 15 * l)
        M:moveX(matrices, smoothSneak * -0.1 * l)
        M:moveZ(matrices, smoothSneak * -0.05)
        M:rotateZ(matrices, smoothSneak * 15 * l)
        break
    end
end

