#version 400 compatibility
#define DIMENSION_END

#define GBUFFERS_TEXTURED
#include "/program/gbuffers_basic.fsh"
