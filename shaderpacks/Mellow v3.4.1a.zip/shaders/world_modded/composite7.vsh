#version 400 compatibility
#define DIMENSION_GENERIC

#include "/program/composite7.vsh"
