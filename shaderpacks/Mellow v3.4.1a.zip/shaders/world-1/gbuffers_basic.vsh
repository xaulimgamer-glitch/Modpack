#version 400 compatibility
#define DIMENSION_NETHER

#include "/program/gbuffers_basic.vsh"
