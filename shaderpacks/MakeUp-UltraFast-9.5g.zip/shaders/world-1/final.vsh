#version 120
#extension GL_ARB_shader_texture_lod : enable
/* MakeUp - final.fsh
Render: Final renderer

Javier Garduño - GNU Lesser General Public License v3.0
*/

#define NETHER
#define FINAL_SHADER
#define NO_SHADOWS

/* Config, uniforms, ins, outs */
#include "/common/final_vertex.glsl"

