#version 120
#extension GL_ARB_shader_texture_lod : enable
/* MakeUp - gbuffers_entities_glowing.vsh
Render: Droped objects, mobs and things like that... glowing

Javier Garduño - GNU Lesser General Public License v3.0
*/

#define THE_END
#define GBUFFER_ENTITIES
#define GBUFFER_ENTITY_GLOW
#define CAVEENTITY_V

#include "/common/solid_blocks_vertex.glsl"
